import { Pessoa } from './pessoa.model';
import { Morada } from './morada.model';
import { PedidoStatus } from './pedido-status.type';
import { NivelConforto } from './nivel-conforto.type';

export interface Pedido {
    _id?: string;
    cliente: Pessoa;
    localizacaoAtual: Morada;
    destino: Morada;
    nivelConforto: NivelConforto;
    numeroPessoas: number;
    status?: PedidoStatus;
    createdAt?: Date;
    updatedAt?: Date;
}
