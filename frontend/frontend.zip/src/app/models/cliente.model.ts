export interface Cliente {
  nome: string;
  nif: string;
  genero: 'masculino' | 'feminino';
}