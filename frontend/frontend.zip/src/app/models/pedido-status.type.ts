export type PedidoStatus = 'pendente' | 'aceite' | 'rejeitado' | 'cancelado';
