// src/app/services/pedido.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, interval } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Pedido } from '../models/pedido.model';

@Injectable({ providedIn: 'root' })
export class PedidoService {
  private apiUrl = 'http://localhost:3000/api/pedidos';

  constructor(private http: HttpClient) {}

  /**
   * Cria um novo pedido de táxi (US6).
   */
  createPedido(pedido: Pedido): Observable<Pedido> {
    return this.http.post<Pedido>(this.apiUrl, pedido);
  }

  /**
   * Retorna um Observable que emite a lista de pedidos pendentes a cada 5s.
   * Usado para polling (US7).
   */
  watchPedidosPendentes(): Observable<Pedido[]> {
    return interval(5000).pipe(
      switchMap(() =>
        this.http.get<Pedido[]>(`${this.apiUrl}?status=pendente`)
      )
    );
  }

  /**
   * Aceita um pedido de táxi (US7).
   */
  acceptPedido(id: string): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.apiUrl}/${id}/aceitar`, {});
  }

  /**
   * Rejeita um pedido de táxi.
   */
  rejectPedido(id: string): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.apiUrl}/${id}/rejeitar`, {});
  }

  /**
   * Cancela um pedido de táxi (US6.e).
   */
  cancelPedido(id: string): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.apiUrl}/${id}/cancelar`, {});
  }
}
